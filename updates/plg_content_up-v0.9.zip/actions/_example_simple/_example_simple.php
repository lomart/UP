<?php

/**
 * DESCRIPTION COURTE
 *
 * suite description
 *
 * syntaxe {up action=option_principale}
 *
 * @author   LOMART
 * @version  1.0
 * @license   <a href="http://www.gnu.org/licenses/gpl-3.0.html" target="_blank">GNU/GPLv3</a>
 *
 */
defined('_JEXEC') or die;

class _example_simple extends upAction {

    function init() {
        // charger les ressources communes à toutes les instances de l'action
        return true;
    }

    function run() {

        // si cette action a obligatoirement du contenu
        if (!$this->ctrl_content_exists()) {
            return false;
        }

        // lien vers la page de demo
        // - vide = page sur le site de UP
        // - URL complete = page disponible sur ce lien
        // - rien pour ne pas proposer d'aide
        $this->set_demopage();

        $options_def = array(
            __class__ => '', // nombre de paragraphe
            'id' => '',
            'class' => '', // classe(s) pour bloc
            'style' => '', // style inline pour bloc
        );

        // fusion et controle des options
        $options = $this->ctrl_options($options_def);

        // attributs du bloc principal
        $attr_main = array();
        $attr_main['class'] = $options['class'];
        $attr_main['style'] = $options['style'];

        // code en retour
        $out = $this->set_attr_tag('div', $attr_main);
        $out .= $this->content;
        $out .= '</div>';

        return $out;
    }

// run
}

// class
