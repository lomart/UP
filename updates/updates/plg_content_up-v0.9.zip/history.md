v0.4.3 - 22-9-17
- ajout ctrl_content_parts & get_content_parts
- blocage liste d'articles

v0.4.2 - 21-9-17
- Up est utilisable pour les blogs d'articles
- image-magnify : chgt nom classe zoom->loupe, bloc pour classe


v0.4.1 - 20-9-17
- restauration de la fonction lang
v0.4 - 20-9-17
- neutralisation nom action 'exotique' -> actionCleanName
- utilisation JText dans les scripts principaux
- ajout propriété actionUserName avant appel init pour msg erreur

v0.3.2 - 20-9-17
- ajout test si article vide
- ajout option make-dico dans upactionslist
v0.3 - 19-9-17
- Version RC
v0.1 - 9-9-17
- Version alpha
