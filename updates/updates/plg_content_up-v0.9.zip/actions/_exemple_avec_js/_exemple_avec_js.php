<?php

/**
 * DESCRIPTION COURTE
 *
 * suite description
 *
 * syntaxe {up nomAction=argument_principal}
 *
 * @author   LOMART
 * @version  1.0
 * @license   <a href="http://www.gnu.org/licenses/gpl-3.0.html" target="_blank">GNU/GPLv3</a>
 *
 */
/* * **************************************************************************** */
/* * **************** ATTENTION CE SCRIPT EST UN MODELE  ************************ */
/**    il ne peux pas fonctionner car les fichiers appelés n'existent pas     * */
/**    Inspirez-vous d'autres actions pour comprendre le fonctionnement       * */
/* * **************************************************************************** */


defined('_JEXEC') or die;

class _exemple_avec_js extends upAction {

    /**
     * charger les ressources communes à toutes les instances de l'action
     * cette fonction n'est lancée qu'une fois pour la première instance
     * @return true
     */
    function init() {
        $this->load_file('fichier.css');
        $this->load_file('fichier.js');
        JHtml::script('https://site.com/script_externe.js');
        return true;
    }

    /**
     * analyse et interprete le shortcode
     * @return [string] [code HTML pour remplacer le shortcode]
     */
    function run() {

        // si cette action a obligatoirement du contenu
        if (!$this->ctrl_content_exists()) {
            return false;
        }

        // lien vers la page de demo
        // - vide = page sur le site de UP
        // - URL complete = page disponible sur ce lien
        // - rien pour ne pas proposer d'aide
        $this->set_demopage();

        // ===== valeur paramétres par défaut (sauf JS)
        $options_def = array(
            __class__ => '', // le paramétre principal
            'id' => '', // id genérée automatiquement par UP
            'class' => '', // classe(s) ajoutées au bloc principal
            'style' => ''    // style inline ajouté au bloc principal
        );

        // ===== paramétres attendus par le script JS
        $js_options_def = array(
            'key' => 'val'
        );

        // fusion et controle des options
        $options = $this->ctrl_options($options_def, $js_options_def);

        // =========== le code JS
        // les options saisies par l'utilisateur concernant le script JS
        // cela évite de toutes les renvoyer au script JS
        $js_options = $this->only_using_options($js_options_def);

        // -- conversion en chaine Json
        // il existe 2 modes: mode1=normal, mode2=sans guillemets
        $js_params = json_arrtostr($js_options);

        // -- initialisation
        $js_code = '$("#' . $options['id'] . '").xxxxx(';
        $js_code .= $js_params;
        $js_code .= ');';
        $this->load_jquery_code($js_code);

        // === le code HTML
        // -- ajout options utilisateur dans la div principale
        $outer_div['id'] = $options['id'];
        $outer_div['class'] = $options['class'];
        $outer_div['style'] = $options['style'];

        // -- le code en retour
        $out = set_attr_tag('div', $outer_div);
        $out .= $this->content;  // le contenu entre les shortcodes ouvrant et fermant
        $out .= '</div>';

        return $out;
    }

// run
}

// class
