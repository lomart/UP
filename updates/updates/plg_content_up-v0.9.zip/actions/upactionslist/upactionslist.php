<?php

/**
 * INTERNE - liste des UP actions avec infos et paramétres
 *
 * syntaxe:
 * {up upactionslist}  toutes les actions
 * {up upactionslist=action1, action2}  une ou plusieurs actions
 *
 * TODO:     sortie sous d'autres formats que FAQ
 *
 * @author   LOMART
 * @update   2017-08-08
 * @version  v1.0 du 08-08-2017
 * @license  <a href="http://www.gnu.org/licenses/gpl-3.0.html" target="_blank">GNU/GPLv3</a>
 */
defined('_JEXEC') or die;

class upactionslist extends upAction {

    function init() {
        //===== Ajout dans le head (une seule fois)
        $this->load_file('faq.js', 'plugins/content/up/assets/js/');

        $css_code = '.upfaq {width: 100%;}';
        $css_code .= '.upfaq-button {';
        $css_code .= '	background-color: #069;';
        $css_code .= '	border-bottom: 1px solid #FFFFFF;';
        $css_code .= '	cursor: pointer;';
        $css_code .= '	padding: 5px 10px;';
        $css_code .= '	color: #FFFFFF;';
        $css_code .= '	font-weight:bold;';
        $css_code .= '}';
        $css_code .= '.upfaq-button small{color:#ddd}';

        $css_code .= '.upfaq-content {';
        $css_code .= '	background-color: ##ddd;';
        $css_code .= '	display: none;';
        $css_code .= '	padding: 10px;';
        $css_code .= '}';
        $css_code .= '.bg-grey{background-color:#aaa;margin:5px 0}';

        $this->load_css_head($css_code);
    }

    function run() {
        // lien vers la page de demo (vide=page sur le site de UP)
        $this->set_demopage();

        $options_def = array(
            $this->name => '', // liste des actions à récupérer. toutes par défaut
            'make-dico' => '0', // consolide le fichier principal dico.json avec ceux des actions
            'id' => '',
            'mode' => 'faq'  // [faq,markdown] présentation du résultat
        );

        // fusion et controle des options
        $options = $this->ctrl_options($options_def);

        // === liste des sous-dossiers du dossier actions (sauf _exemple)
        if ($options[$this->name] == '') {
            // toutes
            $actionsList = $this->up_actions_list();
        } else {
            // uniquement celles demandées
            // TODO : voir à conserver $dico en global
            // charger le dictionnaire
            $dico = file_get_contents($this->upPath . 'dico.json');
            $dico = json_decode($dico, true);

            $tmp = array_map('trim', explode(',', $options[__class__]));
            foreach ($tmp as $key) {
                if (array_key_exists($key, $dico)) {
                    $key = $dico[$key];
                }
                $actionsList[] = str_replace('-', '_', $key);
            }
        }

        // === CONSOLIDATION DU FICHIER DICO.JSON ===
        if ($options['make-dico']) {
            $dicoFolder = $this->up_actions_list();
            $dicoIni = $this->upPath . 'dico.ini';
            $newDico = parse_ini_file($dicoIni);
            foreach ($dicoFolder as $dicoAction) {
                $dicoIni = $this->upPath . 'actions/' . $dicoAction . '/up/dico.ini';
                if (file_exists($dicoIni)) {
                    $tmp = parse_ini_file($dicoIni);
                    $newDico = array_merge($newDico, $tmp);
                }
            }
            $dicoJson = $this->upPath . 'dico.json';
            file_put_contents($dicoJson, json_encode($newDico, JSON_UNESCAPED_SLASHES));
        }


        // === CODE HTML EN RETOUR ===
        // <div id="upfaq">
        // 	<div class="upfaq-button">Button 1</div>
        //   <div class="upfaq-content">Content<br />More Content<br /></div>
        // 	<div class="upfaq-button">Button 2</div>
        // 	<div class="upfaq-content">Content</div>
        // </div>

        $txt = '<div id="upfaq">';
        foreach ($actionsList as $actionName) {

            // === récupération des infos et options
            $actinfos = $this->up_action_infos($actionName);
            $actoptions = $this->up_action_options($actionName);

            $txt .= '<div class="upfaq-button">';
            $txt .= '&#x27A0; ' . $actionName; // fleche et nom action
            $txt .= $this->str_append('', $this->get_dico_synonym($actionName), ' ', ' (', ')');
            $txt .= $this->str_append('', $actinfos['_shortdesc'], ' ', ' : <small>', '</small>');
            // ajout URL pour démo ()remplace _ par - pour alias Joomla
            if ($this->usehelpsite > 0 && $actinfos['_demopage'] != '') {
                $txt .= ' <small>&#x27A0; <a style="color:yellow" href="';
                $txt .= $actinfos['_demopage'] . '"';
                if ($this->usehelpsite == 2) {
                    $txt .= ' target = "_blank"';
                }
                $txt .= '>DEMO</a></small>';
            }
            $txt .= '</div>';

            $txt .= '<div class="upfaq-content">';
            // la description longue
            $txt .= ($actinfos['_longdesc']) ? $actinfos['_longdesc'] : '';
            // les mots-clés
            $txt .= '<div style="background-color:#ddd">';
            foreach ($actinfos as $key => $val) {
                if ($key[0] != '_') {
                    $txt .= ' <span class="label">' . $key . '</span> ' . $val;
                }
            }
            $txt .= '</div>';
            // les options
            $txt .= '<ul>';
            foreach ($actoptions as $key => $val) {
                $txt .= '<li><strong>' . $key . '</strong>: ' . $val;
            }
            $txt .= '<ul>';

            $txt .= '</div>';
        }
        $txt .= '</div>';

        return $txt;
    }

// run
}

// class
