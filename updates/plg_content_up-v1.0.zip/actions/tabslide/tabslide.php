<?php

/**
 * ajoute des onglets pour ouvrir un panneau sur les bords de la fenetre
 *
 * syntaxe {up tabslide=btn-text | tabLocation=top}contenu{/up tabslide}
 *
 * @author    Lomart
 * @version   1.0 - 07/2017
 * @credit    script de <a href="https://github.com/hawk-ip/jquery.tabSlideOut.js" target="_blank">hawk-ip</a>
 * @license   <a href="http://www.gnu.org/licenses/gpl-3.0.html" target="_blank">GNU/GPLv3</a>
 *
 */
defined('_JEXEC') or die;

class tabslide extends upAction {

    function init() {
        // charger les ressources communes à toutes les instances de l'action
        $this->load_file('jquery.tabSlideOut.css');
        $this->load_file('jquery.tabSlideOut.js');
        return true;
    }

    function run() {

        // cette action a obligatoirement du contenu
        if (!$this->ctrl_content_exists()) {
            return false;
        }
        // lien vers la page de demo (vide=page sur le site de UP)
        $this->set_demopage();

        // ===== valeur paramétres par défaut
        // il est indispensable de tous les définir ici
        $options_def = array(
            __class__ => '', // titre de l'onglet
            'id' => '',
            'tab-class' => '', // classe(s) pour onglet
            'tab-style' => '', // css pour onglet
            'panel-class' => '', // classe(s)  pour panneau
            'panel-style' => '', // css pour panneau
        );

        // ===== param JS
        $js_options_def = array(
            'tabLocation' => 'left', // left, right, top or bottom
            'tabHandle' => '.handle', // JQuery selector for the tab, can use #
            'speed' => 300, // time to animate
            'action' => 'click', // action open, 'hover' or 'click'
            'offset' => '200px', // distance pour top or left (bottom or right if offsetReverse is true)
            'offsetReverse' => false, // true= aligné a droite ou en bas
            'otherOffset' => null, // if set, panel size is set to maintain this dist from bottom or right (top or left if offsetReverse)
            'handleOffset' => null, // e.g. '10px'. If null, detects panel border to align handle nicely
            'handleOffsetReverse' => false, // if true, handle aligned with right or bottom of panel
            'bounceDistance' => '50px', // how far bounce event will move everything
            'bounceTimes' => 4, // how many bounces when 'bounce' is called
            'positioning' => 'fixed', // or absolute, so tabs move when window scrolls
            'pathToTabImage' => null, // optional image to show in the tab
            'imageHeight' => null,
            'imageWidth' => null,
            'onLoadSlideOut' => false, // slide out after DOM load
            'clickScreenToClose' => true, // close tab when rest of screen clicked
            'toggleButton' => '.tab-opener', // not often used
            'onOpen' => function() {

            }, // handler called after opening
            'onClose' => function() {

            }     // handler called after closing
        );

        // fusion et controle des options
        $options = $this->ctrl_options($options_def, $js_options_def);

        // les options saisis par l'utilisateur concernant le script JS
        $js_options = $this->only_using_options($js_options_def);
        $js_params = $this->json_arrtostr($js_options);

        // -- ajout code initialisation JS
        $js_code = '$("#' . $options['id'] . '").tabSlideOut(';
        $js_code .= $js_params;
        $js_code .= ');';
        // ajout du code dans head
        $this->load_jquery_code($js_code);

        // ===== STYLER

        $attr_tab['class'] = 'handle';
        $this->add_class($attr_tab['class'], $options['tab-class']);
        $attr_tab['style'] = $options['tab-style'];
        $attr_panel['id'] = $options['id'];
        $attr_panel['class'] = $options['panel-class'];
        $attr_panel['style'] = $options['panel-style'];

        // === code spécifique à l'action
        // qui doit retourner le code pour remplacer le shortcode

        $out = $this->set_attr_tag('div', $attr_panel);
        $out .= $this->set_attr_tag('a', $attr_tab);
        $out .= $options[__class__];
        $out .= '</a>';
        $out .= $this->content;
        $out .= '</div>';

        return $out;
    }

// run
}

// class
