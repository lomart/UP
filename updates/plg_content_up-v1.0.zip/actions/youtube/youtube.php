<?php

/**
 * affiche une video Youtube qui s'inscrit au maxima dans son bloc parent
 *
 * {up youtube=ID}
 * ID : il s'agit du code figurant à la fin de l'URL de la vidéo.
 *
 * @author      LOMART
 * @version     v1.0 du 01-07-2017
 * @license   <a href="http://www.gnu.org/licenses/gpl-3.0.html" target="_blank">GNU/GPLv3</a>
 */
defined('_JEXEC') or die;

class youtube extends upAction {

    function init() {
        // charger les ressources communes à toutes les instances de l'action
        //-- le CSS
        //  http://clic-en-berry.com/comment-rendre-vos-integrations-iframe-youtube-responsive/
        $css_code = '.up-video-container {position: relative; padding-bottom: 56.25%;	height: 0;overflow:hidden;}';
        $css_code .= '.up-video-container iframe{ position:absolute;top:0;left:0;width:100%;height:100%;}';
        $this->load_css_head($css_code);
        return true;
    }

    function run() {

        // lien vers la page de demo (vide=page sur le site de UP)
        $this->set_demopage();

        $options_def = array(
            __class__ => '', // code de la video (à la fin de l'url youtube)
            'id' => '',
            'width' => '', // largeur de la video en px ou %
            'class' => '', // classe pour bloc externe
            'style' => ''     // code css libre pour bloc externe
        );

        // fusion et controle des options
        $options = $this->ctrl_options($options_def);

        // le bloc contenant la video
        $outer_attr['class'] = $options['class'];
        $outer_attr['style'] = '';
        $this->add_style($outer_attr['style'], 'width', $options['width']);
        $this->add_str($outer_attr['style'], $options['style'], ';');

        $main_attr['class'] = 'up-video-container';
        $main_attr['style'] = '';

        // l'iframe de la video
        $attr_iframe['src'] = 'https://www.youtube.com/embed/' . $options[__class__];
        $attr_iframe['frameborder'] = '0';
        $attr_iframe['scrolling'] = 'no';
        $attr_iframe['allowfullscreen'] = null;  // null = attribut sans argument
        // le code renvoyé
        $out = '';
        $out .= ($outer_attr) ? $this->set_attr_tag('div', $outer_attr) : '';
        $out .= $this->set_attr_tag('div', $main_attr);
        $out .= $this->set_attr_tag('iframe', $attr_iframe, true);
        $out .= '</div>';
        $out .= ($outer_attr) ? '</div>' : '';

        return $out;
    }

// run
}

// class
